package com.aris.global.serviceregistryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
